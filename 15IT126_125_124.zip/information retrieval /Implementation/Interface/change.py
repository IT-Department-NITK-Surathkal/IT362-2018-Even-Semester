

def difference(a,b):

    value=0
    for j in range(len(a)):
        count=0
        try:
            testa=a[j].split(',')
            testb=b[j].split(',')
            for i in range(len(testa)):
                #print a[i],b[i],a[i]==b[i]
                #break
                if testa[i]!=testb[i]:
                    count+=1

            value+=float(count)/float(i)
        except:
            continue
    return value/float(len(a))


def getResult(filename):
    f=open('{}.txt'.format(filename),'r')
    temp=[]
    for line in f.readlines():
        temp.append(line.split(':')[1])
    return temp

normal=getResult('normal')
glob=getResult('global')
segment=getResult('segment')
generalize=getResult('generalize')


print 'segement vs global',difference(segment,glob),"%"
print  'segement vs generalize', difference(segment,generalize),"%"
print  'generalize vs global', difference(generalize,glob),"%"
print  'normal vs global',difference(normal,glob),"%"
print  'normal vs segment', difference(normal,segment),"%"
print  'normal vs generalize', difference(normal,generalize),"%"


