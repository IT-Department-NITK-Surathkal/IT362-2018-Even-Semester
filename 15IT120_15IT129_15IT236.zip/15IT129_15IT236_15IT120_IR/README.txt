README:

1. Ensure tensorflow is installed
2. Ensure bAbI 10k dataset is downloaded
3. Ensure path name is reflected in the code sent

We have included a CLI for basic fact checking.
Done By:
Samarth Mohan      15IT236
Siddhanth Pillay   15IT129
Hrishikesh Thakkar 15IT120