from __future__ import unicode_literals
from .forms import UserForm
from django.shortcuts import render
from django.contrib.auth import authenticate, login , logout
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from .models import UserInpu
from .preprocessor import nltk_preprocess
from .update_profile import update_positive_profile,update_negative_profile,flush
from .genetic_algorithm import get_relevant_docs_first_time,get_relevant_docs
from .models import PositiveIndexTerm,NegativeIndexTerm,BluLabData,I2B2Data
from collections import OrderedDict
from collections import Counter
import math

@login_required(login_url='/IRSystem/login/')
def search(request):
    return render(request,'IRSystem/search.html',{})


def register(request):
    registered = False

    if request.method == 'POST':
        user_form = UserForm(data=request.POST)

        if user_form.is_valid():

            user = user_form.save()
            user.set_password(user.password)
            user.save()

            registered = True

        else:
            print user_form.errors

    else:
        logout(request)
        user_form = UserForm()

    if registered == True:
        return render(request, 'IRSystem/login.html',{})

    return render(request,
            'IRSystem/register.html',
            {'user_form': user_form, 'registered': registered},
            )


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if user:
            if user.is_active:
                login(request, user)
                return render(request,'IRSystem/search.html', {'user': user, })
            else:
                return HttpResponse("Sorry. Your account is disabled.")
        else:
            print "Invalid login details: {0}, {1}".format(username, password)
            error_message = "Invalid Username or Password. Please try again"
            return render(request,'IRSystem/login.html',{ 'error_message':error_message, })

    else:
        logout(request)
        return render(request,'IRSystem/login.html', {})


@login_required(login_url='/IRSystem/login/')
def get_details(request):
    if request.method == 'POST':
        username = request.POST['username']
        active_user = User.objects.get(username=username)
        return render(request,'IRSystem/myDetails.html',{'active_user':active_user})
    else:
        return render(request,'IRSystem/no_get.html',{'active_user':active_user})


@login_required(login_url='/IRSystem/login/')
def process_doc(request):
    if request.method == 'POST':
        username = request.POST['username']
        active_user = User.objects.get(username=username)
        flush(active_user)
        doc_terms = request.POST['document_terms']
        icd_code = request.POST['icd_code']

        request.session['sum_of_averages'] = 0.0
        request.session['averages'] = []
        request.session['precision_at_k'] = []
        request.session['iteration_of_relevance'] = 0
        request.session['cgs'] = []
        request.session['dcgs'] = []
        request.session['idcgs'] = []
        request.session['ndcgs'] = []
        
        if request.FILES:
            doc_file = request.FILES['files']
            doc_file_name = request.FILES['files'].name
        else:
            doc_file = None
            doc_file_name = ''

        if doc_terms != '':
            inp = UserInpu.objects.create(type='Text',user=active_user,inpu=doc_terms)
            inp.save()
            index_terms,term_frequencies = nltk_preprocess(doc_terms)
            updated = update_positive_profile(index_terms,term_frequencies,active_user,'very relevant','only relevant')

        if doc_file != None:
            request.session['selected_doc_file'] = doc_file_name
            inp = UserInpu.objects.create(type='File',user=active_user,inpu=doc_file_name)
            inp.save()
            doc_terms = doc_file.read()
            index_terms, term_frequencies = nltk_preprocess(doc_terms)
            updated = update_positive_profile(index_terms, term_frequencies, active_user, 'very relevant','only relevant')

        if icd_code != '':
            request.session['selected_icd_code'] = icd_code
            inp = UserInpu.objects.create(type='Code',user=active_user,inpu=icd_code)
            inp.save()
            file = open('/home/armour/Desktop/Django/IRProject/MedicalIR_i2b2/i2b2/all_files/'+icd_code+'.txt','r')
            doc_terms = file.read()
            file.close()
            index_terms, term_frequencies = nltk_preprocess(doc_terms)
            updated = update_positive_profile(index_terms, term_frequencies, active_user, 'very relevant','only relevant')

        positive_terms = PositiveIndexTerm.objects.filter(current_query=True,profile=active_user.user_p).order_by('-adjusted_frequency')
        top_10_positive_terms = positive_terms[:20]
        selected_docs = get_relevant_docs_first_time(top_10_positive_terms,doc_file_name,icd_code)
        selected_docs.sort(key=lambda x:x[1],reverse=True)
        print(selected_docs)
        selected_doc_objs = OrderedDict()
        for doc in selected_docs:
            file = open('/home/armour/Desktop/Django/IRProject/MedicalIR_i2b2/i2b2/all_files/'+doc[0]+'.txt','r')
            doc_text = file.read()
            file.close()
            selected_doc_objs[doc[0]] = doc_text
        return render(request,'IRSystem/relevance_feedback.html', {'user': active_user, 'selected_doc_objs': selected_doc_objs, })
    else:
        return render(request,'IRSystem/no_get.html',{'active_user':active_user})


@login_required(login_url='/IRSystem/login/')
def process_relevance_feedback(request):
    if request.method == 'POST':
        username = request.POST['username']
        active_user = User.objects.get(username=username)
        if request.POST.get('stop'):
            relevance_lis = []
            codes_lis = []
            for i in range(1,11):
                relevance_lis.append((request.POST[str(i)].split('#'))[1])
                codes_lis.append((request.POST[str(i)].split('#'))[0])
            print("Relevance List : ")
            print(relevance_lis)

            binary_relevance_list = []
            for i in relevance_lis:
                if i == 'Very Relevant' or i == 'Relevant':
                    binary_relevance_list.append(1)
                else:
                    binary_relevance_list.append(0)
            dcg_rel_list = []
            for i in relevance_lis:
                if i == 'Very Relevant':
                    dcg_rel_list.append(4)
                elif i == 'Relevant':
                    dcg_rel_list.append(3)
                elif i == 'Irrelevant':
                    dcg_rel_list.append(1)
                elif i == 'Very Irrelevant':
                    dcg_rel_list.append(0)
                else:
                    dcg_rel_list.append(2)

            print("Relevance List - Numbers : ")
            print(dcg_rel_list)

            cg_sum = 0
            for i in range(len(dcg_rel_list)):
                cg_sum = cg_sum + dcg_rel_list[i]

            dcg_sum = 0
            for i in range(len(dcg_rel_list)):
                if i == 0:
                    dcg_sum = dcg_sum + dcg_rel_list[i]
                else:
                    dcg_sum = dcg_sum + (dcg_rel_list[i]*1.0)/(math.log(i+1,2))
            idcg_sum = 0
            idcg_rel_list = sorted(dcg_rel_list,reverse=True)
            for i in range(len(idcg_rel_list)):
                if i == 0:
                    idcg_sum = idcg_sum + idcg_rel_list[i]
                else:
                    idcg_sum = idcg_sum + (idcg_rel_list[i]*1.0)/(math.log(i+1,2))
            ndcg = (dcg_sum*1.0)/idcg_sum

            print("With a 5 point relevance scale: \n0 - Very Irrelevant\n  1 - Irrelevant\n 2 - Not Sure\n 3 - Relevant\n 4 - Very Relevant\n")
            print("Cumulative Gain: {}".format(cg_sum))
            print("DCG: {}".format(dcg_sum))
            print("IDCG: {}".format(idcg_sum))
            print("NDCG: {}\n".format(ndcg))

            request.session['cgs'].append(cg_sum)
            request.session['dcgs'].append(dcg_sum)
            request.session['idcgs'].append(idcg_sum)
            request.session['ndcgs'].append(ndcg)

            ret=0.0
            rel=0.0
            x=0.0
            prec=[]
            x=0.0
            Avg=0.0
            Sum_Avg= float(request.session['sum_of_averages'])
            #precision at k
            #if feedback is binary
            rel_count = binary_relevance_list.count(1)
            for i in binary_relevance_list:
                if i==1:
                    ret=ret+1.0
                    rel=rel+1.0
                    x=x+(rel/(ret*1.0))
                else:
                    ret=ret+1.0

                prec.append(rel/ret)
                    
                
            print("Precision at K values")
            print prec

            if(rel_count!=0):
                Avg = ((x*1.0)/rel_count)
            else:
                Avg = 0.0

            Avg=((x*1.0)/rel_count)
            print "Average precision = "+str(Avg)
            Sum_Avg+=Avg
            print("Sum of Averages : ")
            print(Sum_Avg)
            print("\n")
            
            request.session['precision_at_k'].append(prec)
            request.session['averages'].append(Avg)
            request.session['sum_of_averages'] = Sum_Avg
            request.session['iteration_of_relevance'] = int(request.session['iteration_of_relevance']) + 1

            print("\n\n\n")
            print("Summary of Evaluation")
            print("Number of Iterations of Relevance Feedback: {}\n".format(int(request.session['iteration_of_relevance'])))
            print("Precision @ K values at each iteration")
            for itera in range(int(request.session['iteration_of_relevance'])):
                print("\n")
                print("Iteration {}".format(itera+1))
                print("Precision at K values:")
                print((request.session['precision_at_k'])[itera])
                print("Average Precision : {}".format(float((request.session['averages'])[itera])))
                print("\nCG : {}".format(float((request.session['cgs'])[itera])))
                print("DCG : {}".format(float((request.session['dcgs'])[itera])))
                print("IDCG : {}".format(float((request.session['idcgs'])[itera])))
                print("NDCG : {}\n".format(float((request.session['ndcgs'])[itera])))
            print("\n")
            print("Sum of Average Precisions in all {} iterations : ".format(int(request.session['iteration_of_relevance'])))
            print(float(request.session['sum_of_averages']))
            print("\nMean Average Precision : ")
            MAP = float(request.session['sum_of_averages'])/(1.0 * int(request.session['iteration_of_relevance']))
            print(MAP)
            print("\n")
            return render(request,'IRSystem/search.html', {'user': active_user, })
        relevance_lis = []
        codes_lis = []
        for i in range(1,11):
            relevance_lis.append((request.POST[str(i)].split('#'))[1])
            codes_lis.append((request.POST[str(i)].split('#'))[0])
        print("Relevance List : ")
        print(relevance_lis)

        binary_relevance_list = []
        for i in relevance_lis:
            if i == 'Very Relevant' or i == 'Relevant':
                binary_relevance_list.append(1)
            else:
                binary_relevance_list.append(0)

        dcg_rel_list = []
        for i in relevance_lis:
            if i == 'Very Relevant':
                dcg_rel_list.append(4)
            elif i == 'Relevant':
                dcg_rel_list.append(3)
            elif i == 'Irrelevant':
                dcg_rel_list.append(1)
            elif i == 'Very Irrelevant':
                dcg_rel_list.append(0)
            else:
                dcg_rel_list.append(2)

        print("Relevance List - Numbers : ")
        print(dcg_rel_list)

        cg_sum = 0
        for i in range(len(dcg_rel_list)):
            cg_sum = cg_sum + dcg_rel_list[i]

        dcg_sum = 0
        for i in range(len(dcg_rel_list)):
            if i == 0:
                dcg_sum = dcg_sum + dcg_rel_list[i]
            else:
                dcg_sum = dcg_sum + (dcg_rel_list[i]*1.0)/(math.log(i+1,2))
        idcg_sum = 0
        idcg_rel_list = sorted(dcg_rel_list,reverse=True)
        for i in range(len(idcg_rel_list)):
            if i == 0:
                idcg_sum = idcg_sum + idcg_rel_list[i]
            else:
                idcg_sum = idcg_sum + (idcg_rel_list[i]*1.0)/(math.log(i+1,2))
        ndcg = (dcg_sum*1.0)/idcg_sum

        print("With a 5 point relevance scale: \n 0 - Very Irrelevant\n 1 - Irrelevant\n 2 - Not Sure\n 3 - Relevant\n 4 - Very Relevant\n")
        print("Cumulative Gain: {}".format(cg_sum))
        print("DCG: {}".format(dcg_sum))
        print("IDCG: {}".format(idcg_sum))
        print("NDCG: {}\n".format(ndcg))

        request.session['cgs'].append(cg_sum)
        request.session['dcgs'].append(dcg_sum)
        request.session['idcgs'].append(idcg_sum)
        request.session['ndcgs'].append(ndcg)

        ret=0.0
        rel=0.0
        x=0.0
        prec=[]
        x=0.0
        Avg=0.0
        Sum_Avg= float(request.session['sum_of_averages'])

        rel_count = binary_relevance_list.count(1)
        for i in binary_relevance_list:
            if i==1:
                ret=ret+1.0
                rel=rel+1.0
                x=x+(rel/(ret*1.0))
            else:
                ret=ret+1.0

            prec.append(rel/ret)
                
            
        print("Precision at K values")
        print prec

        if(rel_count!=0):
            Avg = ((x*1.0)/rel_count)
        else:
            Avg = 0.0

        Avg=((x*1.0)/rel_count)
        print "Average precision = "+str(Avg)
        Sum_Avg+=Avg
        print("Sum of Averages : ")
        print(Sum_Avg)
        print("\n")
        request.session['precision_at_k'].append(prec)
        request.session['averages'].append(Avg)
        request.session['sum_of_averages'] = Sum_Avg
        request.session['iteration_of_relevance'] = int(request.session['iteration_of_relevance']) + 1

        print("Codes List : ")
        print(codes_lis)
        very_rel_terms = []
        rel_terms = []
        non_rel_terms = []
        very_non_rel_terms = []
        for i in range(len(codes_lis)): 
            o = I2B2Data.objects.filter(icd9_code=codes_lis[i])
            for obj in o:
                if(relevance_lis[i] == 'Very Relevant'):
                    temp = obj.index_term
                    temp2 = temp.split(" ")
                    for t in temp2:
                        very_rel_terms.append(t)
                if(relevance_lis[i] == 'Relevant'):
                    temp = obj.index_term
                    temp2 = temp.split(" ")
                    for t in temp2:
                        rel_terms.append(t)

        for i in range(len(codes_lis)): 
            o = I2B2Data.objects.filter(icd9_code=codes_lis[i])
            for obj in o:
                if(relevance_lis[i] == 'Irrelevant'):
                    temp = obj.index_term
                    temp2 = temp.split(" ")
                    for t in temp2:
                        non_rel_terms.append(t)
                if(relevance_lis[i] == 'Very Irrelevant'):
                    temp = obj.index_term
                    temp2 = temp.split(" ")
                    for t in temp2:
                        very_non_rel_terms.append(t)

        very_relevant_terms_list_of_tup = []
        relevant_terms_list_of_tup = []

        for term in very_rel_terms:
            if term in non_rel_terms:
                very_relevant_terms_list_of_tup.append((term,1.2))
                non_rel_terms = [t for t in non_rel_terms if t != term]
            elif term in very_non_rel_terms:
                very_relevant_terms_list_of_tup.append((term,1.2))
                very_non_rel_terms = [t for t in very_non_rel_terms if t != term]
            else:
                very_relevant_terms_list_of_tup.append((term,1.0))

        for term in rel_terms:
            if term in non_rel_terms:
                relevant_terms_list_of_tup.append((term,1.2))
                non_rel_terms = [t for t in non_rel_terms if t != term]
            elif term in very_non_rel_terms:
                relevant_terms_list_of_tup.append((term,1.2))
                very_non_rel_terms = [t for t in very_non_rel_terms if t != term]
            else:
                relevant_terms_list_of_tup.append((term,1.0))

        temp1 = []
        temp2 = []
        for term in relevant_terms_list_of_tup:
            if term[1] == 1.2:
                temp1.append(term[0])
            elif term[1] == 1.0:
                temp2.append(term[0])        

        tup1 = Counter(temp1).most_common(len(temp1))
        update_positive_profile(temp1,tup1,active_user,'relevant','both')
        tup2 = Counter(temp2).most_common(len(temp2))
        update_positive_profile(temp2,tup2,active_user,'relevant','only relevant')

        temp1 = []
        temp2 = []
        for term in very_relevant_terms_list_of_tup:
            if term[1] == 1.2:
                temp1.append(term[0])
            elif term[1] == 1.0:
                temp2.append(term[0])        

        tup1 = Counter(temp1).most_common(len(temp1))
        update_positive_profile(temp1,tup1,active_user,'very relevant','both')
        tup2 = Counter(temp2).most_common(len(temp2))
        update_positive_profile(temp2,tup2,active_user,'very relevant','only relevant')

        tup1 = Counter(non_rel_terms).most_common(len(non_rel_terms))
        update_negative_profile(non_rel_terms,tup1,active_user,'irrelevant')

        tup2 = Counter(very_non_rel_terms).most_common(len(very_non_rel_terms))
        update_negative_profile(very_non_rel_terms,tup2,active_user,'very irrelevant')

        positive_terms = PositiveIndexTerm.objects.filter(current_query=True,profile=active_user.user_p).order_by('-adjusted_frequency')
        top_16_positive_terms = positive_terms[:16]

        negative_terms = NegativeIndexTerm.objects.filter(current_query=True,profile=active_user.user_n).order_by('-N_frequency')
        top_4_negative_terms = negative_terms[:4]

        selected_doc_objs = OrderedDict()
        ctr = 0
        already_selected_codes = []

        for i in range(len(codes_lis)):
            if relevance_lis[i] == 'Very Relevant':
                file = open('/home/armour/Desktop/Django/IRProject/MedicalIR_i2b2/i2b2/all_files/'+codes_lis[i]+'.txt','r')
                doc_text = file.read()
                file.close()
                selected_doc_objs[codes_lis[i]] = doc_text
                ctr = ctr + 1
                already_selected_codes.append(codes_lis[i])

        for i in range(len(codes_lis)):
            if relevance_lis[i] == 'Relevant':
                file = open('/home/armour/Desktop/Django/IRProject/MedicalIR_i2b2/i2b2/all_files/'+codes_lis[i]+'.txt','r')
                doc_text = file.read()
                file.close()
                selected_doc_objs[codes_lis[i]] = doc_text
                ctr = ctr + 1
                already_selected_codes.append(codes_lis[i])

        for i in range(len(codes_lis)):
            if relevance_lis[i] == 'Irrelevant' or relevance_lis[i] == 'Very Irrelevant':
                already_selected_codes.append(codes_lis[i])

        if request.session.get('selected_icd_code') and request.session.get('selected_icd_code')!= '':
            already_selected_codes.append(request.session.get('selected_icd_code'))

        if request.session.get('selected_doc_file') and request.session.get('selected_doc_file')!= '':
            d = request.session.get('selected_doc_file')
            d1 = d[0:len(d)-4]
            already_selected_codes.append(request.session.get('selected_icd_code'))

        already_selected_codes = list(set(already_selected_codes))
        print(already_selected_codes)

        selected_docs = get_relevant_docs(top_16_positive_terms,top_4_negative_terms,10-ctr,already_selected_codes)
        selected_docs.sort(key=lambda x:x[1],reverse=True)
        print(selected_docs)
        for doc in selected_docs:
            file = open('/home/armour/Desktop/Django/IRProject/MedicalIR_i2b2/i2b2/all_files/'+doc[0]+'.txt','r')
            doc_text = file.read()
            file.close()
            selected_doc_objs[doc[0]] = doc_text
        return render(request,'IRSystem/relevance_feedback.html', {'user': active_user, 'selected_doc_objs': selected_doc_objs, })

    else:
        return render(request,'IRSystem/no_get.html',{'active_user':active_user})