from .models import PositiveProfile,PositiveIndexTerm,NegativeProfile,NegativeIndexTerm
from django.core.exceptions import ObjectDoesNotExist


def update_positive_profile(index_terms,term_frequencies,user,relevance,sens):
    profile,created = PositiveProfile.objects.get_or_create(user_p=user)
    if relevance == 'very relevant':
        weight = 1.2
    else:
        weight = 1.0
    if sens == 'only relevant':
        sens = 1.0
    else:
        sens = 1.2
    for tup in term_frequencies:
        term = tup[0]
        freq = tup[1]
        frequency = tup[1]*weight
        sensitivity = sens
        adjusted_frequency = frequency*sensitivity
        try:
            obj = PositiveIndexTerm.objects.get(profile=profile,term=term,current_query=True)
            frequency = frequency + obj.frequency
            adjusted_frequency = frequency * sensitivity
            obj.frequency = frequency
            obj.adjusted_frequency = adjusted_frequency
            obj.save()
        except ObjectDoesNotExist:
            PositiveIndexTerm.objects.create(current_query=True,profile=profile,term=term,frequency=frequency,sensitivity=sensitivity,adjusted_frequency=adjusted_frequency)


    return True


def update_negative_profile(index_terms,term_frequencies,user,relevance):
    profile,created = NegativeProfile.objects.get_or_create(user_n=user)
    if relevance == 'very irrelevant':
        weight = 1.2
    else:
        weight = 1.0
    for tup in term_frequencies:
        term = tup[0]
        freq = tup[1]
        frequency = tup[1]*weight
        try:
            obj = NegativeIndexTerm.objects.get(profile=profile,N_term=term,current_query=True)
            frequency = frequency + obj.N_frequency
            obj.N_frequency = frequency
            obj.save()
        except ObjectDoesNotExist:
            NegativeIndexTerm.objects.create(current_query=True,profile=profile,N_term=term,N_frequency=frequency)

def flush(user):
    try:
        profile = PositiveProfile.objects.get(user_p=user)
        o = PositiveIndexTerm.objects.filter(current_query=True,profile=profile)
        for obj in o:
            obj.current_query = False
            obj.save()
    except ObjectDoesNotExist:
        to_do = 'do nothing'
    try:
        profile = NegativeProfile.objects.get(user_n=user)
        o = NegativeIndexTerm.objects.filter(current_query=True,profile=profile)
        for obj in o:
            obj.current_query = False
            obj.save()
    except ObjectDoesNotExist:
        to_do = 'do nothing'