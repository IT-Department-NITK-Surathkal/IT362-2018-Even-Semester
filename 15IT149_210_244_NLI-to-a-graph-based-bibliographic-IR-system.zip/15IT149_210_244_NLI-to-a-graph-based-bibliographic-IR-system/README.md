## IR Mini Project

#### A natural language interface to a graph-based bibliographic information retrieval system


Group members:
- Snigdha Taduru \[15IT149\]
- Rishita Golla  \[15IT210\]
- Shreya Shetty  \[15IT244\]

Project link:
https://drive.google.com/file/d/1TcR-jxAY7dLd5CdghQbph-TTBDdc4xdl/view
