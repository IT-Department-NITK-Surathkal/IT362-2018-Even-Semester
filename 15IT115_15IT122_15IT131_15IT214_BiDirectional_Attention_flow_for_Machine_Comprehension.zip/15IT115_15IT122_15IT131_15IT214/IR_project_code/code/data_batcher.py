"""This file contains code to read tokenized data from file,
truncate, pad and process it into batches ready for training"""
from __future__ import absolute_import
from __future__ import division

import random
import time
import re

import numpy as np
from six.moves import xrange
from nlp_functions.word_and_character_vectors import UNK_ID, PAD_ID
from nlp_functions.sentence_operations import split_by_whitespace,sentence_to_word_ids,pad_words,convert_ids_to_word_vectors

class Batch(object):
    """A class to hold the information needed for a training batch"""

    def __init__(self,context_ids,context_mask,context_tokens,context_glove_vectors,qn_ids,qn_mask,qn_tokens,qn_glove_vectors,ans_span,ans_tokens,uuids=None):
        self.context_ids = context_ids
        self.context_mask = context_mask
        self.context_tokens = context_tokens
        self.context_glove_vectors=context_glove_vectors

        self.qn_ids = qn_ids
        self.qn_mask = qn_mask
        self.qn_tokens = qn_tokens
        self.qn_glove_vectors=qn_glove_vectors

        self.ans_span = ans_span
        self.ans_tokens = ans_tokens

        self.uuids = uuids

        self.batch_size = len(self.context_tokens)

def intstr_to_intlist(string):
    """Given a string e.g. '311 9 1334 635 6192 56 639', returns as a list of integers"""
    return [int(s) for s in string.split()]

def refill_batches(batches,word2id_glove,context_file,qn_file,ans_file, batch_size, context_len, question_len, discard_long):
    """
    Adds more batches into the "batches" list.
    """
    print ("Refilling batches...")
    tic = time.time()
    examples = [] # list of (qn_ids, context_ids, ans_span, ans_tokens) triples
    context_line, qn_line, ans_line = context_file.readline(), qn_file.readline(), ans_file.readline() # read the next line from each

    while context_line and qn_line and ans_line: # while you haven't reached the end

        # Convert tokens to word ids
        #context_tokens, context_ids = sentence_to_token_ids(context_line, word2id_glove)
        #qn_tokens, qn_ids = sentence_to_token_ids(qn_line, word2id_glove)
        context_tokens, context_ids = sentence_to_word_ids(context_line, word2id_glove)
        qn_tokens, qn_ids = sentence_to_word_ids(qn_line, word2id_glove)
        ans_span = intstr_to_intlist(ans_line)

        # read the next line from each file
        context_line, qn_line, ans_line = context_file.readline(), qn_file.readline(), ans_file.readline()

        # get ans_tokens from ans_span
        assert len(ans_span) == 2
        if ans_span[1] < ans_span[0]:
            print ("Found an ill-formed gold span: start=%i end=%i" % (ans_span[0], ans_span[1]))
            continue
        ans_tokens = context_tokens[ans_span[0] : ans_span[1]+1] # list of strings

        # discard or truncate too-long questions
        if len(qn_ids) > question_len:
            if discard_long:
                continue
            else: # truncate
                qn_ids = qn_ids[:question_len]

        # discard or truncate too-long contexts
        if len(context_ids) > context_len:
            if discard_long:
                continue
            else: # truncate
                context_ids = context_ids[:context_len]

        # add to examples
        examples.append((context_ids, context_tokens, qn_ids, qn_tokens, ans_span, ans_tokens))

        # stop refilling if you have 160 batches
        if len(examples) == batch_size * 160:
            break

    # Once you've either got 160 batches or you've reached end of file:

    # Sort by question length
    # Note: if you sort by context length, then you'll have batches which contain the same context many times (because each context appears several times, with different questions)
    examples = sorted(examples, key=lambda e: len(e[2]))

    # Make into batches and append to the list batches
    for batch_start in xrange(0, len(examples), batch_size):

        # Note: each of these is a list length batch_size of lists of ints (except on last iter when it might be less than batch_size)
        context_ids_batch, context_tokens_batch, qn_ids_batch, qn_tokens_batch, ans_span_batch, ans_tokens_batch = zip(*examples[batch_start:batch_start+batch_size])

        batches.append((context_ids_batch, context_tokens_batch, qn_ids_batch, qn_tokens_batch, ans_span_batch, ans_tokens_batch))

    # shuffle the batches
    random.shuffle(batches)

    toc = time.time()
    print ("Refilling batches took %.2f seconds" % (toc-tic))
    return


def get_batch_generator(word2id_glove,emb_matrix_glove, context_path, qn_path, ans_path, batch_size, context_len, question_len, discard_long):
    """
    This function returns a generator object that yields batches.
    """
    context_file, qn_file, ans_file = open(context_path,encoding='utf-8'), open(qn_path,encoding='utf-8'), open(ans_path,encoding='utf-8')
    batches = []

    while True:
        if len(batches) == 0: # add more batches
            refill_batches(batches, word2id_glove, context_file, qn_file, ans_file, batch_size, context_len, question_len, discard_long)
        if len(batches) == 0:
            break

        # Get next batch. These are all lists length batch_size
        (context_ids, context_tokens, qn_ids, qn_tokens, ans_span, ans_tokens) = batches.pop(0)

        # Pad context_ids and qn_ids
        #qn_ids = padded(qn_ids, question_len) # pad questions to length question_len
        #context_ids = padded(context_ids, context_len) # pad contexts to length context_len
        qn_ids = pad_words(qn_ids, question_len)  # pad questions to length question_len
        context_ids = pad_words(context_ids, context_len) # pad contexts to length context_len
        context_glove=convert_ids_to_word_vectors(context_ids,emb_matrix_glove)
        qn_glove = convert_ids_to_word_vectors(qn_ids, emb_matrix_glove)
        context_glove=np.array(context_glove)
        qn_glove=np.array(qn_glove)

        # Make qn_ids into a np array and create qn_mask
        qn_ids = np.array(qn_ids) # shape (batch_size, question_len)
        qn_mask = (qn_ids != PAD_ID).astype(np.int32) # shape (batch_size, question_len)

        # Make context_ids into a np array and create context_mask
        context_ids = np.array(context_ids) # shape (batch_size, context_len)
        context_mask = (context_ids != PAD_ID).astype(np.int32) # shape (batch_size, context_len)

        # Make ans_span into a np array
        ans_span = np.array(ans_span) # shape (batch_size, 2)

        # Make into a Batch object
        batch = Batch(context_ids, context_mask, context_tokens,context_glove, qn_ids, qn_mask, qn_tokens,qn_glove, ans_span, ans_tokens)

        yield batch

    return
