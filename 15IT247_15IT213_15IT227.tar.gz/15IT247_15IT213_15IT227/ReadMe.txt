IT362 Even Semester 2018 Course Project

Project Title:Medical Image Retrieval using ML

Team Members: 
		Swaroop Ranganath 15IT247
		Jyoti Prakash Sahoo 15IT213
		Poojan Shah 15IT227

Project Description:

This project aims to classify and retrieve medical images by classify them into semantic classes and retrieving images with the most similarity to the query image.The feature vector extracted has 101 dimensions which is reduced by using PCA to 6.The images are then classified into their classes by using a combination of SVM and KMeans.Their confidence measures are calculated and used.When a query image is given,the system calculates its semantic class and retrieves it.Next,the predicted classes' top relevant images are computed and retrieved.The number of images retrieved can be dynamically set.The accuracy can be tested by the retrieve.py file with the CalcAcc() method and the retrieval for a input image given by the GetImages() method.

  
