import pandas as pd
import cv2
import numpy as np
import os 

for filename in os.listdir('../ClassCSV'):
	name,ext=os.path.splitext(filename)
	name=name+'Cen'
	df=pd.read_csv(os.path.join('../ClassCSV',filename),header=None)
	df=df.drop(df.columns[[0]],axis=1)
	#print df
	if(len(df.index)>2):
		arr=np.array(df)
		#print len(df.index)
		arr=np.float32(arr)
		criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)

		flags = cv2.KMEANS_RANDOM_CENTERS

		compactness,labels,centers = cv2.kmeans(arr,3,None,criteria,10,flags)
		#print type(centers)
		centers2=centers.tolist()
		#print centers
		'''ct=[]
		ctp=[]
		for i in centers:
			ctp=[]
			for j in i:
				ctp.append(int(j))
			ct.append(ctp)'''
		df2=pd.DataFrame(centers2)
		#print ct
	else:
		df2=df
	df2.to_csv(os.path.join('./KMCen',(name+'.csv')),index=False,header=False)
