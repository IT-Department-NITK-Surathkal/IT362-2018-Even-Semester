import os
import featureext as ft
import pandas as pd

features=[]

df=pd.read_csv("../Dataset/FinalData.csv")
ID=list(df.ID)
cl=list(df.ClassLabel)
#ind=list(df.Index)
#ind=range(5)
for filename in os.listdir("../Images/ImageCLEFmed2009_train.02"):
	name,ext=os.path.splitext(filename)
	if '(' in name or ')' in name:
		continue
	else:
		num=int(name)
		try:
			ind=ID.index(num)
			print num
			lab=cl[ind]
			feature=ft.getFeat(os.path.join('../Images/ImageCLEFmed2009_train.02',filename))
			feature.insert(0,lab)
			feature.insert(0,num)
			features.append(feature)
		except ValueError:
			print name+" Not Valid"
			continue
	
#FeatData=zip(ind,features)
df2=pd.DataFrame(features)
df2.to_csv("Extract.csv")


	
