import pandas as pd
import numpy as np

df=pd.read_csv("ImageCLEFmed2009_train_codes.02.csv")
classlab=list(df.class1)
num=list(df.image_id)
#dataset=zip(num,classlab)
#FinalData=[]
count=1
'''for num,label in dataset:
	temp=[]
	if label=='\\N':
		continue
	else:
		#temp=[count,num,label]
		#FinalData.append(temp)
		count+=1
#print len(dataset)
#print len(FinalData)
df2=pd.DataFrame(data=FinalData,columns=['Index','ID','ClassLabel'])
df2.to_csv('FinalData.csv',index=False,header=True)'''
unique=set(classlab)
unique.remove('\\N')
test=list(unique)
test2=map(int,test)
test2.sort()
print test2
