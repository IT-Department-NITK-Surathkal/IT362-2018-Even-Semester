from __future__ import division
import numpy as np
import pandas as pd
import os
import GetClass as gc
import random
import ImageClass as ic
import featureext as ft
from sklearn.externals import joblib
import cv2

def CalcAcc(dataset):
	df=pd.read_csv(dataset)
	ID=list(df.ID)
	cl=list(df.ClassLabel)

	n=0
	splitval=100
	totacc=[0]*2
	epsacc=[0]*2
	omgacc=[0]*2
	acc=[0]*2
	for id,clab in zip(ID,cl):
		if n%100==0 and n!=0:
			print "\n"+str(n-splitval)+" to "+str(n)
		
			acct=[i/splitval for i in totacc]
			acce=[i/splitval for i in epsacc]
			acco=[i/splitval for i in omgacc]
			acc=[i/splitval for i in acc]
			#print "Precision of KMeans "+str(acct[0])
			#print "Precision of SVM "+str(acce[0])
			#print "Precision of Final "+str(acc[0])
			print acct
			print acce
			#print acco
			print acc
			totacc=[0]*2
			epsacc=[0]*2
			omgacc=[0]*2
			acc=[0]*2
			print "\n"
			if n==100:
				break
			#print id,clab,n
		else:
			print n
			filename=os.path.join("../Images/ImageCLEFmed2009_train.02",str(id)+".png")
			pclab,pceps,pcomg=gc.GetClass(filename)
			if pclab==clab:
				totacc[0]+=1
			else:
				totacc[1]+=1
			if pceps==clab:
				epsacc[0]+=1
			else:
				epsacc[1]+=1
			if pcomg==clab:
				omgacc[0]+=1
			else:
				omgacc[1]+=1
			pre=random.random()
			if pre>=0.5:
				pred=pclab
			else:
				pred=pceps
			if pred==clab:
				acc[0]+=1
			else:
				acc[1]+=1
				
		n+=1
def getImages(filename):
	pca=joblib.load(os.path.join("../FeatureExtraction/PCA",'PCA.pkl'))
	feature=ft.getFeat(filename)
	classlab,ceps,comg=gc.GetClass(filename)
	print classlab,ceps,comg
	nfeat=pca.transform([feature])
	neat=list(nfeat[0])
	#pr=clf.predict_proba([neat])
	imgs=ic.RetrieveImages(str(ceps),neat)
	#print imgs
	num=1
	imgs=map(str,imgs)
	print imgs
	for i in imgs:
		fname=os.path.join("../Images/ImageCLEFmed2009_train.02",i+".png")
		ret=cv2.imread(fname)
		ret = cv2.resize(ret, (200, 300))
		#cv2.imshow("Result_"+str(num),ret)
		cv2.imwrite("./Results/Result_"+str(num)+".png",ret)
		num+=1
		
	


#CalcAcc("../Dataset/FinalData.csv")
getImages('../Images/ImageCLEFmed2009_train.02/370846.png')
