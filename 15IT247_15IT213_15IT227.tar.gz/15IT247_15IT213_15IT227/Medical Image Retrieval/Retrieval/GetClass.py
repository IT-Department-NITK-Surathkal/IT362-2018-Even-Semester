import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.decomposition import PCA
import os
import cv2
import featureext as ft
#import Retrieve as rt

def GetClass(filename):
	cli=range(1,58)
	cli2=map(str,cli)

	clf=joblib.load(os.path.join("../SVM/Model",'Model.pkl'))
	df=pd.read_csv("../FeatureExtraction/Extract.csv")
	pca=joblib.load(os.path.join("../FeatureExtraction/PCA",'PCA.pkl'))
	df2=df.drop(df.columns[[0,1,2]],axis=1)
	mat=df2.as_matrix()

	#pca=PCA(n_components=6)

	#filename="../TestImages/Tester/1879.png"
	#pca.fit(mat)
	feature=ft.getFeat(filename)
	#print len(feature)
	nfeat=pca.transform([feature])
	#print list(neat[0])
	neat=list(nfeat[0])
	pr=clf.predict_proba([neat])
	predict=clf.predict([neat])
	#print predict
	epsilon=list(pr[0])
	#print epsilon
	#epsilon=[1-i for i in epsilon]
	#print epsilon
	omega=[]
	for i in cli2:
		#print i
		clab=int(i)
		#epsilon=[]
		#omega=[]
		finaldat=[]
		#df=pd.read_csv(os.path.join("../ClassCSV","Class"+i+".csv"))
		df2=pd.read_csv(os.path.join("../KMeans/KMCen3","Class"+i+"Cen.csv"))
		df2=df2.drop(df2.columns[[0]],axis=1)
		feat1=np.float32(neat)
		nfeat1=np.ones(shape=(1,6))
		nfeat1=cv2.normalize(feat1,nfeat1,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
		#print len(nfeat1)
		tot=0
		for k in range(len(df2.index)+1):
			try:
				feat2=list(df2.iloc[k])		
				feat2=np.float32(feat2)
				nfeat2=np.ones(shape=(1,6))
				nfeat2=cv2.normalize(feat2,nfeat2,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
				#print len(nfeat2)
				a=cv2.compareHist(nfeat1,nfeat2,cv2.HISTCMP_CHISQR)
				tot+=a
			except IndexError:
				continue
		omg=tot/(len(df2.index)+1)
		omega.append(omg)

	dat=[]
	classeps=int(predict[0])
	classomg=omega.index(min(omega))	
	for eps,omg in zip(epsilon,omega):
		dat.append((eps)*(omg))
	minval=min(dat)
	classlab=dat.index(minval)
	return (classlab+1),classeps,(classomg+1)
'''print "Class Label is " +str(classlab+1)
images=rt.RetrieveImages(str(classlab+1),neat)
print images'''


	
		

	 
	
