import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.decomposition import PCA
import os
import cv2

K=10
def RetrieveImages(classlab,feature):
	df=pd.read_csv(os.path.join("../ProbCalc/ProbRank(New)","Class"+classlab+"Rank.csv"))
	df2=pd.read_csv(os.path.join("../ClassCSV","Class"+classlab+".csv"))
	df2=df2.drop(df2.columns[[0,1]],axis=1)
	ID=list(df.ID)
	epsilon=list(df.Epsilon)
	omega=list(df.Omega)
	dist=[]
	df=df.drop(df.columns[[0,1,2,3]],axis=1)
	feat1=np.float32(feature)
	nfeat1=np.ones(shape=(1,6))
	nfeat1=cv2.normalize(feat1,nfeat1,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
	#print len(nfeat1)
	for k in range(len(df2.index)):
		feat2=list(df2.iloc[k])	
		#print len(feat2)	
		feat2=np.float32(feat2)
		nfeat2=np.ones(shape=(1,6))
		nfeat2=cv2.normalize(feat2,nfeat2,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
		#print len(nfeat2)
		a=cv2.compareHist(nfeat1,nfeat2,cv2.HISTCMP_CHISQR)
		dist.append(a)
	dat=[]
	for eps,omg,dst in zip(epsilon,omega,dist):
		dat.append(eps*omg*dst)
	ind=np.argpartition(dat, -K)[-K:]
	#print ind
	out=[ID[i] for i in ind]
	return out
		
