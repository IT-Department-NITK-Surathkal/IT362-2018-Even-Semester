# Person-re-identification

1. Revanth B S 		15IT137
2. Akshay U Prabhu 	15IT203
3. Hafeez Ali A 	15IT252
