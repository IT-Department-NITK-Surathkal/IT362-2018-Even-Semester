Base Paper - mobilenet_ssd.pdf
Report - CV_Report.pdf
Presentation - ppt_final.pdf
ssd_prototxt.txt - prototxt file for mobilenet ssd
SSD_deploy.caffemodel - pre-trained weights 

Source Code
1. ssd_detector.py - detects objects in images saved in 'images' folder
How to run:
python ssd_detector.py --prototxt ssd_prototxt.txt --model SSD_deploy.caffemodel --image images

Detections saved in the folder 'detections'


2. ssd_video_detection.py - detects objects in a live video stream
How to run:
python ssd_video_detection.py --prototxt ssd_prototxt.txt --model SSD_deploy.caffemodel

Team Members:
Aparna Menon - 15IT152
Sanjana B - 15IT239
Swati S Bhat - 15IT249
