
# coding: utf-8

# In[1]:


from keras.models import Sequential
from keras.utils import np_utils
from keras.layers.core import Dense, Activation, Dropout

import pandas as pd
import numpy as np


# In[2]:


import pandas as pd
import numpy as np


# In[3]:


data = pd.read_csv('data/infy(97-18).csv')
# data[:,1]


# In[5]:


# data[['Prev Close','Open Price', 'High Price','Low Price', 'Last Price', 'Close Price', 'Average Price', 
# 'Total Traded Quantity', 'Turnover', 'No. of Trades', 'Deliverable Qty']]


# In[6]:


# data[['Open Price', 'High Price','Low Price', 'Last Price', 'Close Price']]


# In[7]:


classes = [1 if y >= x else 0 for (x,y) in zip ( list(data['Average Price'][:-3]), list(data['Average Price'][3:]) )]


# In[8]:


# x = data[['Prev Close','Open Price', 'High Price','Low Price', 'Close Price', 'Average Price', 
#           'Total Traded Quantity', 'Turnover', 'No. of Trades', 'Deliverable Qty']]
x = data[['Open Price', 'High Price','Low Price', 'Close Price',
          'Total Traded Quantity', 'No. of Trades', 'Deliverable Qty']]


# In[9]:


x.replace('-',0,inplace=True)


# In[15]:


x = np.array(x).astype('float64')
x = x[:-1]
x = x / x.max(axis=0)
# x.mean(axis=0)


# In[16]:


dataset = np.array(list(zip(x,classes)))


# In[17]:


np.random.shuffle(dataset)


# In[18]:


X = [dataset[x][0] for x in range(len(dataset))]
X = np.array(X)
y = [dataset[x][1] for x in range(len(dataset))]
y = np.array(y)

from keras.utils import to_categorical
y = to_categorical(y)


# In[19]:


from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.1)


# In[20]:


input_dim = X_train.shape[1]
output_dim = y_train.shape[1]

model = Sequential()
model.add(Dense(256, input_dim=input_dim))
model.add(Activation('relu'))
model.add(Dropout(0.3))

model.add(Dense(256))
model.add(Activation('relu'))
model.add(Dropout(0.3))

model.add(Dense(output_dim))
model.add(Activation('softmax'))

# we'll use categorical xent for the loss, and RMSprop as the optimizer
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])


# In[21]:


model.fit(X_train,y_train,epochs=10, batch_size=16, verbose=1, validation_data=(X_test, y_test))


# In[22]:


model.summary()

