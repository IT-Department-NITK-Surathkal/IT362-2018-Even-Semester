# Readme
==

1) Install python packages by: pip install -r requirements.txt
2) Run main.py for the base implementation
3) Run MLP.py to run the multi latered perceptron model.

