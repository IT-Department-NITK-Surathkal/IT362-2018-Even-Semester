bso.py - bees swarm optimization file

Usage - python bso.py
