###################
Dataset
###################

medline - folder containing MEDLINE dataset and the generated medical text files 

###################
Source Code (to be executed as given in the sequence below)
###################

1. vsm.ipynb - performs vector space modelling and k-means clustering on the MEDLINE dataset

Run the jupyter notebook to run the file

2. apriori - folder containing files for apriori frequent pattern mining on the documents. Contains a readme file that contains instructions for the execution of the code.

3. pct - folder containing files for closed frequent pattern mining using pattern count tree. Readme included.

4. bso - folder containing file for running bees swarm optimization. Readme included.
