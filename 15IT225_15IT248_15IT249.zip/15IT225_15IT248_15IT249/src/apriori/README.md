Ref - https://github.com/asaini/Apriori


List of files
-------------
1. apriori.py
2. apriori_clean.csv
3. README(this file)


Usage
-----
To run the program with dataset provided and default values for *minSupport* = 0.15 and *minConfidence* = 0.6

    python apriori.py -f apriori_clean.csv

To run program with dataset  

    python apriori.py -f apriori_clean.csv -s 0.17 -c 0.68

Best results are obtained for the following values of support and confidence:  

Support     : Between 0.102 and 0.2  

Confidence  : Between 0.5 and 0.7 


