pct_v1.py - generates reduced PC-Tree for the example given in the CFPM_PCT.pdf paper

Usage - python pct_v1.py

pct_v2.py - generates closed frequent patterns from the apriori frequent pattern terms generated from MEDLINE documents

Usage - python pct_v2.py
