Project Title - Bees Swarm Optimization guided by data mining techniques for document information retrieval.

Readme included in src folder containing source files.

