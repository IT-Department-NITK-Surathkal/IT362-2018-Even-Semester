import re
import os
import string
import nltk
from nltk.stem.snowball import EnglishStemmer
from nltk.corpus import stopwords
from collections import defaultdict
import pickle

#Document class which stores each document object
class Document:
	def __init__(self,docID,title,abstract):
		self.table=str.maketrans(" "," ",string.punctuation)
		self.docID=docID
		self.title=title.translate(self.table)
		self.abstract=abstract.translate(self.table)
		self.length=len(abstract.split())

	def __str__(self):
		return self.title

def build_dataset(num=30):
	file=open(os.path.join(os.path.abspath(os.path.dirname(__file__)),'ohsumed.87'),'r').read()
	f=file.split('.I')
	documents=[]
	for i in f[1:num]:
		docID=re.search(r'(?<=\.U\n)[0-9]+',i)
		title=re.search(r'(?<=\.T\n).*',i)
		abstract=re.search(r'(?<=\.W\n).*',i)
		
		if docID and title and abstract:
			documents.append(Document(docID.group(),title.group(),abstract.group()))
	return documents

def build_inverted_index(documents):
	inverted_index=defaultdict(list)
	len_docs=0
	for document in documents:
		docID=document.docID
		title=[t.lower() for t in nltk.word_tokenize(document.title)]
		abstract=[t.lower() for t in nltk.word_tokenize(document.abstract)]
		for token in title:
			if token in stopwords.words('english'):
				continue
			token=EnglishStemmer().stem(token)
			if docID not in inverted_index[token]:
				inverted_index[token].append(docID)
		for token in abstract:
			if token in stopwords.words('english'):
				continue
			token=EnglishStemmer().stem(token)
			if docID not in inverted_index[token]:
				inverted_index[token].append(docID)
		len_docs=len_docs+document.length
	avg_len_docs=len_docs/len(documents)
	return inverted_index,avg_len_docs

#Get the corpus and build inverted index
documents=build_dataset()
file=open('documents','wb')
pickle.dump(documents,file)
file.close()
inverted_index,avg_len=build_inverted_index(documents)
file=open('inv_index','wb')
pickle.dump(inverted_index,file)
file.close()