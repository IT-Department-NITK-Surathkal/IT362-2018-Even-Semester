from django.shortcuts import render
from django.http import HttpResponse
import numpy as np
import math
import nltk
from nltk.stem.snowball import EnglishStemmer
import os
from .inverted_index import build_dataset,avg_len
from nltk.corpus import stopwords
import pickle
documents=build_dataset()
file=open(os.path.abspath(os.path.dirname(__file__))+'/inv_index','rb')
inverted_index=pickle.load(file)
file.close()
	
def trim_query(query):
	query=[t.lower() for t in nltk.word_tokenize(query)]
	trimed_query=[]
	for token in query:
		if token in stopwords.words('english'):
			continue
		trimed_query.append(EnglishStemmer().stem(token))
	return trimed_query

def generate_vocabulary(R):
	V=[]
	for document in R:
		title=[t.lower() for t in nltk.word_tokenize(document.title)]
		abstract=[t.lower() for t in nltk.word_tokenize(document.abstract)]
		for token in title:
			if token in stopwords.words('english') or token in V:
				continue
			V.append(EnglishStemmer().stem(token))
		for token in abstract:
			if token in stopwords.words('english') or token in V:
				continue
			V.append(EnglishStemmer().stem(token))
	return V

#Fixed constants
alpha0=0.99
gamma=0.9
theta=0.9

#Okapi BM25 Model for Original Query
def bm(doc,orig_query):
	score=0
	for t in orig_query:
		score=score+weight(t,doc)
	return score

def weight(term,document):
	tf=0
	title=[t.lower() for t in nltk.word_tokenize(document.title) if t==term]
	abstract=[t.lower() for t in nltk.word_tokenize(document.abstract) if t==term]
	tf=len(title)+len(abstract)	
	if tf==0:
		return 0
	k=2
	b=0.5
	doc_length=document.length
	avg_len_docs=avg_len
	total_docs=len(documents)
	term_docs=len(inverted_index[term])
	score=(tf/(k*((1-b)+b*(doc_length/avg_len_docs))+tf))*(math.log((total_docs-term_docs+0.5)/term_docs+0.5)/math.log(2))
	return score

def search_index(doc,term):
	doc_list=inverted_index.get(term) 
	for j in doc_list:
		if j==doc:
			return True
	return False

#Fitness function
def fitness_function(orig_query,query,R):
	S={}
	for j in query:
		for k in R:
			if k.docID not in S.keys() :
				if search_index(k.docID,j) == True:
					S[k.docID]=bm(k,orig_query)+bm(k,query)
	L=S.values()
	return max(L)

def move(eq1,eq2,alpha,V):
	beta=1/(1+gamma*hamming_distance(eq1,eq2))
	for i,t in enumerate(eq1):
		if t not in eq2:
			random_value=np.random.random_sample()
			if random_value<beta:
				# count = np.random.random_integers(len(eq2)-1)
				# time=0
				# while(eq2[count] in eq1 and time<5):
				# 	count = np.random.random_integers(len(eq2)-1)
				# 	time=time+1
				options=[term for term in eq2 if term not in eq1]
				if len(options)>1:
					eq1[i]=options[np.random.random_integers(len(options)-1)]
				elif len(options)==1:
					eq1[i]=options[0]
			if random_value<alpha:
				rand=np.random.random_integers(len(V)-1)
				# time=0
				# while (V[rand] in eq1 and time<5):
				# 	rand=np.random.random_integers(len(V)-1)
				# 	time=time+1
				eq1[i]=V[rand]
	return eq1	

def hamming_distance(eq1,eq2):
	union=[]
	for j in eq1:
		if j not in union:
			union.append(j)
	for j in eq2:
		if j not in union:
			union.append(j)
	distance=len(eq1)+len(eq2)-len(union)
	return distance

def modified_query(query,num_doc,inverted_index):
	idf=dict()
	mod_query=[]
	length_query=len(query)-2
	count=0
	for term in query:
		idf_value=calculate_idf(term,num_doc,inverted_index)
		if idf_value!=0:
			idf[term]=idf_value
	for key,value in sorted(idf.items(),key=lambda x:x[1]):
		if count==length_query:
			break
		mod_query.append(key)
		count+=1
	return mod_query

def calculate_idf(term,num_doc,inverted_index):
	N=num_doc
	n_i=max(len(inverted_index[term]),1)
	return math.log(N/n_i)/math.log(2)

def initialize_population(V,size=30,length=3):
	fireflies=[[] for i in range(size)]
	for i in range(size):
		firefly=np.random.permutation(V)[:length].tolist()
		while True:
			if firefly not in fireflies:
				fireflies[i]=firefly
				break
			firefly=np.random.permutation(V)[:length].tolist()
	return fireflies

def firefly_algorithm(fireflies,V,R,query,max_iter=10):
	population_size=len(fireflies)
	#Calculate initial fitness of each firefly
	fitness=np.zeros(population_size)
	for i in range(population_size):
		fitness[i]=fitness_function(query,fireflies[i],R)
	best_firefly=[]
	best_fitness=0
	for k in range(max_iter):
		alpha=alpha0*gamma**k
		for i in range(population_size):
			for j in range(population_size):
				if i!=j and fitness[i]<fitness[j]:
					fireflies[i]=move(fireflies[i],fireflies[j],alpha,V)
					fitness[i]=fitness_function(query,fireflies[i],R)
		best_position=np.argmax(np.array(fitness))
		if fitness[best_position]>best_fitness:
			best_fitness=fitness[best_position]
			best_firefly=fireflies[best_position]
		print("Current best firefly : ",best_firefly)
	return best_firefly

# Create your views here.
def index(request):
	if request.method=='GET':
		query=request.GET.get('query','')
	if(query==''):
		return render(request,'index.html',{'message':"Empty search"})
	oquery=query
	query=trim_query(query)
	query1=modified_query(query,len(documents),inverted_index)
	print("Preprocesses query : ",query)

	#To retrieve the pseudo relevant documents : Okapi BM25 Model
	score={}
	#R : List of relevant documents in sorted order
	R=[]
	for i,document in enumerate(documents):
		score[i]=bm(document,query)
	for key,value in sorted(score.items(),key=lambda x:x[1],reverse=True):
		R.append(documents[key])

	num_top_results=7
	print("*******************************************************************")
	print("Pseudo relevant documents : ")
	for i in range(num_top_results):
		print(R[i])
	print("*******************************************************************")
	print("Firefly algorithm to find expanded query : ")

	#Step 1 : Generate the vocabulary of Pseudo relevant documents
	V=generate_vocabulary(R[:7])
	fireflies=initialize_population(V,10)
	print("Generated fireflies : ",fireflies)
	additional_query=firefly_algorithm(fireflies,V,R,query)
	expanded_query=query+additional_query
	print("*******************************************************************")
	print("Best expanded query : ",expanded_query)
	print("*******************************************************************")
	#Get the final relevant documents
	# R_=[]
	# for i,document in enumerate(documents):
	# 	score[i]=bm(document,expanded_query)
	# for key,value in sorted(score.items(),key=lambda x:x[1],reverse=True):
	# 	R_.append(documents[key])

	# print("Relevant documents : ")
	# for i in range(num_top_results):
	# 	print(R_[i])
	# 	#print(R_[i].title,R_[i].docID,R_[i].abstract)
	# result=R_
	result=R[:7]
	abstract=[]
	for j in range(len(result)):
		abstract.append(R[j].abstract)
	return render(request,'index.html',{'context':result,'abstract':abstract,'query':additional_query,'orig':nltk.word_tokenize(oquery),'mod':query1})
