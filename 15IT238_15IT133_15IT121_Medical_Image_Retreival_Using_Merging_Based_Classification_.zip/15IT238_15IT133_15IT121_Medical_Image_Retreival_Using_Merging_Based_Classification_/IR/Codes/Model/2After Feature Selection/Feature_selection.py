from pandas import read_csv
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
import numpy as np

array = np.loadtxt('IRIS.csv',delimiter=',')
#total number of initial features is 313

X = array[:,0:313]
Y = array[:,313]

#a binary classification model is used to select features
model = LogisticRegression()

#the number of optimised features is 120 in this case
rfe = RFE(model, 120)
fit = rfe.fit(X, Y)
print("Num Features: %d") % fit.n_features_ #Displays the number of optimised features
print("Selected Features: %s") % fit.support_  #For every displays a value 0 or 1, where 1 represents that it is present in the optimised set 
print("Feature Ranking: %s") % fit.ranking_  #Ranks the features according to their weight
