import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report,confusion_matrix

image = pd.read_csv('final.csv')
X=image.drop(image.columns[313], axis=1)
y=image[image.columns[312]]

# Splitting Data into train and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y)

# Standardistaion by calculating mean and std dev
scaler = StandardScaler()
scaler.fit(X)

X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

#Using model 
mlp = MLPClassifier(hidden_layer_sizes=(13),max_iter=5000)
mlp.fit(X_train,y_train)

#predicting output
predictions = mlp.predict(X_test)
print(mlp.score(X_test,y_test))
