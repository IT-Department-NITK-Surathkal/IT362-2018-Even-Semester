# Example of Naive Bayes implemented from Scratch in Python
import csv
import random
import math

accDict=dict()
def randomChromosomes(chromosomeLength):
    return [random.randint(0,1) for i in range(chromosomeLength)]  

def chromosomeGen(popSize,chromosomeLength):
    return [randomChromosomes(chromosomeLength) for j in range(popSize)]
	
	
#Select features and find fitness value of each chromosome	
def selectFeature(population,dataset):
	selectedFeatureList=list()
	selectedFeatures=list()
	fitness=list()
	for row in range(len(population)):
		for col in range(len(population[row])):
		#for col in range(0,1):
			if population[row][col]==1:
				selectedFeatures.append(col)
		#print "sel:",selectedFeatures
		data=createFeaturesSet(selectedFeatures)
		selectedFeatures=[]
		#return data
		#print "row:",row
		fit=chk(data,population[row])
		#print "fit:",fit
		fitness.append(fit)	
	return fitness
				
#Create dataset with only the selected features
def createFeaturesSet(selectedFeatures):
	selectedFeatureList=list()
	data=list()
	for row in range(len(dataset)):
		for col in selectedFeatures:
			selectedFeatureList.append(dataset[row][col])
		selectedFeatureList.append(dataset[row][-1])
		data.append(selectedFeatureList)
		selectedFeatureList=[]
	#print data
	return data
	

def loadCsv(filename):
	lines = csv.reader(open(filename, "rU"))
	dataset = list(lines)
	dataset.pop(0)
	'''for row in dataset:
		i=0
		if row[44]=="No":
			row[44]=0
		else:
			row[44]=1'''
	for i in range(len(dataset)):
		dataset[i] = [float(x) for x in dataset[i]]
	return dataset

def splitDataset(dataset, splitRatio):
	trainSize = int(len(dataset) * splitRatio)
	trainSet = []
	copy = list(dataset)
	while len(trainSet) < trainSize:
		index = random.randrange(len(copy))
		trainSet.append(copy.pop(index))
	return [trainSet, copy]

def separateByClass(dataset):
	separated = {}
	for i in range(len(dataset)):
		vector = dataset[i]
		if (vector[-1] not in separated):
			separated[vector[-1]] = []
		separated[vector[-1]].append(vector)
	return separated

def mean(numbers):
	return sum(numbers)/float(len(numbers))

def stdev(numbers):
	avg = mean(numbers)
	#variance = sum([pow(x-avg,2) for x in numbers])/float(len(numbers)-1)



















































































































































































































































































































































































	.






















	
	variance = sum([pow(x-avg,2) for x in numbers])/float(len(numbers))
	return math.sqrt(variance)

def summarize(dataset):
	summaries = [(mean(attribute), stdev(attribute)) for attribute in zip(*dataset)]
	del summaries[-1]
	return summaries

def summarizeByClass(dataset):
	separated = separateByClass(dataset)
	summaries = {}
	for classValue, instances in separated.iteritems():
		summaries[classValue] = summarize(instances)
	return summaries

def calculateProbability(x, mean, stdev):
	try:
		exponent = math.exp(-(math.pow(x-mean,2)/(2*math.pow(stdev,2))))
	except:
		return 0
	return (1 / (math.sqrt(2*math.pi) * stdev)) * exponent

def calculateClassProbabilities(summaries, inputVector):
	probabilities = {}
	for classValue, classSummaries in summaries.iteritems():
		probabilities[classValue] = 1
		for i in range(len(classSummaries)):
			mean, stdev = classSummaries[i]
			x = inputVector[i]
			probabilities[classValue] *= calculateProbability(x, mean, stdev)
	return probabilities
			
def predict(summaries, inputVector):
	probabilities = calculateClassProbabilities(summaries, inputVector)
	bestLabel, bestProb = None, -1
	for classValue, probability in probabilities.iteritems():
		if bestLabel is None or probability > bestProb:
			bestProb = probability
			bestLabel = classValue
	return bestLabel

def getPredictions(summaries, testSet):
	predictions = []
	for i in range(len(testSet)):
		result = predict(summaries, testSet[i])
		predictions.append(result)
	return predictions

def getAccuracy(testSet, predictions):
	correct = 0
	for i in range(len(testSet)):
		if testSet[i][-1] == predictions[i]:
			correct += 1
	return (correct/float(len(testSet))) * 100.0
	

def chk(dataset,chromosome):
	trainingSet, testSet = splitDataset(dataset, splitRatio)
	#print('Split {0} rows into train={1} and test={2} rows').format(len(dataset), len(trainingSet), len(testSet))
	# prepare model
	summaries = summarizeByClass(trainingSet)
	# test model
	predictions = getPredictions(summaries, testSet)
	accuracy = getAccuracy(testSet, predictions)
	#accList.append(accuracy)
	accDict[accuracy]=chromosome
	#print('Accuracy: {0}%').format(accuracy),"ch:",chromosome
	#print('ACC: {0}%').format(accuracy)
	return accuracy

def calcProbability(fitness):
	totalFitness=sum(fitness)
	cumulativeProbability=list()
	probability=[fitnessValue/totalFitness for fitnessValue in fitness]
	for i in range(len(probability)):
		cumulativeProbability.append(sum(probability[0:i+1]))
	#print "cum:",cumulativeProbability
	return cumulativeProbability

def generateRandomNumber():
	randomNumList=list()
	for i in range(len(population)):
		randomNumList.append(random.random())
	return randomNumList
		
def selectChromosome(cumulativeProbability,randomNumList,population):
	newPopulation=[[]]*len(population)
	for i in range(len(randomNumList)):
		for j in range(len(cumulativeProbability)):
			if cumulativeProbability[j]>randomNumList[i]:
				newPopulation[i]=population[j]
				break
	
	return newPopulation
	
def crossOver(cr,population):
	randomNumList=generateRandomNumber()
	selectedForCrossOver=list()
	copyOfPopulation=population
	#print "rand cross:",randomNumList
	for i in range(len(randomNumList)):
		if randomNumList[i]<cr:
			selectedForCrossOver.append(i)
	
	#range(len(selectedForCrossOver)):
	
	"""ct=0
	for i in population:
		print i,"--",ct
		ct=ct+1"""
	ct=0
	if len(selectedForCrossOver)>1:
		#for each selected chromosome
		for i in selectedForCrossOver:
			#split from 1 to chromosomeLen-1
			
			#print "i,ct,next",i,ct+1,selectedForCrossOver[ct+1]
			split=random.randint(1,119)
			#print "split:",split
			#iterate thru each gene in a chromosome
			for j in range(split,120):
				copyOfPopulation[i][j]=population[selectedForCrossOver[ct+1]][j]
				#print "copy[",i,"]:","j:",j,"p:",population[selectedForCrossOver[ct+1]][j],copyOfPopulation[i]
			ct=ct+1
			if ct==len(selectedForCrossOver)-1:
				break
	population=copyOfPopulation	
	"""print "POP new:"
	ct=0
	for i in copyOfPopulation:
		print i,"--",ct
		ct=ct+1
	return population"""
	return population
	
def mutation(mr,population):
	mutatedChromosome=mr*30*120
	j=0
	#print "POP**************************8:",population
	while j<=mutatedChromosome:
		row=random.randint(0,len(population)-1)
		col=random.randint(0,119)
		#print "row,col:",row,col
		population[row][col]=random.randint(0,1)
		j=j+1
	return population
	

filename = 'modified120.csv'
splitRatio = 0.67
dataset = loadCsv(filename)
chromosomeLength=120
popSize=30
population=chromosomeGen(popSize,chromosomeLength)



for i in range(1,10):
	#print "it:",i
	fitness=selectFeature(population,dataset)
	cumulativeProbability=calcProbability(fitness)
	randomNumList=generateRandomNumber()
	population=selectChromosome(cumulativeProbability,randomNumList,population)
	cr=0.25
	mr=0.1
	population=crossOver(cr,population)
	population=mutation(mr,population)
	
#print accDict
m= max(accDict.keys())
print m
print "Suitable chromosome:",accDict[m]