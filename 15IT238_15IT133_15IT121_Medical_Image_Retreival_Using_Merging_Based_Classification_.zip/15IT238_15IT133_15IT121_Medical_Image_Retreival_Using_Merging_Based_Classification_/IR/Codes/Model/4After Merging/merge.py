r=open('2.txt','r')
a=[]
for val in r.read().split():
    a.append(int(val))

for i in range(0,len(a)):
    if(a[i]==6 or a[i]==7):
        a[i]=5
    if(a[i]==9 or a[i]==10):
        a[i]=8
    if(a[i]==13 or a[i]==14 or a[i]==15 or a[i]==16 or a[i]==17 or a[i]==18):
        a[i]=12
    if(a[i]==20 or a[i]==21 or a[i]==22):
        a[i]=19
    if(a[i]==24 or a[i]==25 or a[i]==26):
        a[i]=23
    if(a[i]==35 or a[i]==37 or a[i]==38 or a[i]==39):
        a[i]=34
    if(a[i]==52 or a[i]==53):
        a[i]=47

thefile = open('test.txt', 'w')
for item in a:
  thefile.write("%s\n" % item)