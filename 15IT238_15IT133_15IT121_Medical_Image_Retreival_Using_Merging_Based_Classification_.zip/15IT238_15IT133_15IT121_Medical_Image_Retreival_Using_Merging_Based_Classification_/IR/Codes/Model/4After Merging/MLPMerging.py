import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report,confusion_matrix

image = pd.read_csv('mergeoutput.csv')
X=image.drop(image.columns[66], axis=1)
y=image[image.columns[66]]

X_train, X_test, y_train, y_test = train_test_split(X, y)

scaler = StandardScaler()
scaler.fit(X)

X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

mlp = MLPClassifier(hidden_layer_sizes=(13),max_iter=5000)

mlp.fit(X_train,y_train)

predictions = mlp.predict(X_test)
print(mlp.score(X_test,y_test))

# Merging Classes
a=[]
for i in range(1,58):
    ind=[]
    k=0
    for x in y_test:
        if(x==i):
            ind.append(predictions[k])
        k=k+1
    a.append(ind)

k=1
clasac=[]
for i in a:
    count=0
    total=len(i)
    if (total==0):
        total=1
    for x in i:
        if(x==k):
            count=count+1
    acc=count/float(total)
    clasac.append(acc)
    k=k+1

hg=0
for ii in range(0,56):
    ind=[]
    for j in range(0,56):
        if(clasac[ii]<0.6 and clasac[j]<0.6 and clasac[ii]!=0 and clasac[j]!=0):
            countt=0
            ki=len(a[ii])
            kj=len(a[j])
            for i in a[ii]:
                if(i==j):
                    countt=countt+1
            pki=countt/(ki+kj)
            if(pki>0.1):
                hg=hg+1
                print(ii,"-",j)
