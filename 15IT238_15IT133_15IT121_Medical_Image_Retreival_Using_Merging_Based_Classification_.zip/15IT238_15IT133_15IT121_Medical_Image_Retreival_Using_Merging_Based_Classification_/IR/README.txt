# Readme
Medical Image Retreival using Merging Based Classification on Image CLEF Dataset

MLP - Multilayer Perceptron Model

# Feature Extraction

1. Scripts
   1.1 feature - Main function.
   1.2 fd - Fourier Descriptor
   1.3 Texture - Texture Feature
   1.4 Invariant - Invariant Feature
    1.4.1 Cent_Moment - Calulating central Cent_Moment
    1.4.2 feature_vec - seven invariant moments
   1.5 hist - Histogram Feature

2. Feature .csv
    2.1 final - fd + Texture + Invariant + hist
    2.2 fd - Fourier Descriptor
    2.3 Texture - Texture Feature
    2.4 Invariant - Invariant Feature
    2.5 hist - Histogram Feature

# Model

1. Basic
    1.1 MLP-Basic - MLP on feature vector

2. Feature Selection
    2.1 MLPFeatureSelection - MLP on selected feature vector
    2.2 modified80 - feature vector length-80
    2.2 modified100 - feature vector length-100
    2.2 modified120 - feature vector length-120
    2.2 modified150 - feature vector length-150

3. Genetic Algorithm
    3.1 MLPGa - MLP on GA output
    3.2 gaoutput - modified feature vector after ga

4. Merging Scheme
    4.1 MLPMerging - MLP on merged classes output
    4.2 merge - To merge classes
