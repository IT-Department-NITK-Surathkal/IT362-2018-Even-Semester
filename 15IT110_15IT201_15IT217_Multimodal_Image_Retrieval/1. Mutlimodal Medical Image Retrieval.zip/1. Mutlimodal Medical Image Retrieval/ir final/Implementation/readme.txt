Dependancies -

tensorflow
opencv2
lda

******************************
To run - python filename

where filename could be -

1. evaluate_just_visual.py
2. evaluate_vistex.py
3. evaluation_autoencoder.py
4. evaluation_vgg.py
5. ensemble.py

******************************
